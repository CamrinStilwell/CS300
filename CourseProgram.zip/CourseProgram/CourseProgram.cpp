/*--------------------------
* CourseProgram.cpp
* Camrin Stilwell
* CS 300
* 7-1: Project Two
  -------------------------*/
#include <iostream>
#include <fstream>
#include <String>
#include <vector>

using namespace std;

//define course structure
struct Course {
	string courseNum;
	string name;
	vector<string> prerequisites;
};

//Split string for list of strings with delimiter
vector<string> tokenize(string a, string d = " ") {
	vector<string>stringArray;
	int start = 0;
	int end = a.find(d);

	while (end != -1) {
		stringArray.push_back(a.substr(start,end - start));
		start = end + d.size();
		end = a.find(d, start);
	}
	stringArray.push_back(a.substr(start,end - start));
	return stringArray;
}
//Open file and store information into list of courses
vector<Course> OpenFile() {
	//Creates an object of ifstream class to open file
	ifstream file("abcu.txt",ios::in);
	vector<Course> courses;
	string line;
	
	//while loop to go through each line
	while (1) {
		
		 getline(file,line);
		//if end of file, end loop
		if (line == "-1")
			break;
		Course course;

		//get tokenize information from comma separation 
		vector<string>courseInfo = tokenize(line, ",");
		//store information on structure course
		course.courseNum = courseInfo[0];
		course.name = courseInfo[1];
		//if prerequisites, store details
		for (int i = 2; i < courseInfo.size(); i++) {
			course.prerequisites.push_back(courseInfo[i]);
		}
		//add course to course list
		courses.push_back(course);
	}
	//return list of courses and close file
	file.close();
	return courses;
	
	
}

//print course information
void printCourse(Course course) {
	string courseNum = course.courseNum;
	string name = course.name;
	vector<string> prerequisites = course.prerequisites;
	cout << courseNum <<", ";
	cout << name << endl;
	cout << "Prerequisites: ";
	for (int i = 0; i < prerequisites.size(); i++) {
		cout << prerequisites[i] << " ";
	}
	cout << "\n\n";
}

//print course list
void printList(vector<Course> courses) {
	int n = courses.size();
	//sort through the list
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			if (courses[j].courseNum > courses[j + 1].courseNum) {
				swap(courses[j + 1], courses[j]);
			}
		}
	}
	//go through list to print all
	for (int i = 0; i < n; i++) {
		printCourse(courses[i]);
	}
}

//search for course from user input
void searchList(vector<Course> courses) {
	int n = courses.size();
	string courseNum;
	int f = 0;
	cout << "Enter course number: ";
	cin >> courseNum;

	for (int i = 0; i < n; i++) {
		//if course is found, print
		if (courses[i].courseNum == courseNum) {
			f = 1;
			printCourse(courses[i]);
			break;
		}
	}

	//if course could not be found, print error message
	if (f == 0) {
		cout << "ERROR: Course not found\n";
	}
}

//main using argument count and value
int main(int argc, char** argv) {
	vector<Course> courses;
	//print menu
	cout << "1: Load Data Structure\n";
	cout << "2: Print Course List\n";
	cout << "3: Print Course\n";
	cout << "4: Exit\n";

	int input;
	//break loop when user enters '4'
	do {
		cout << "\nEnter menu number: ";
		cin >> input;
		switch (input) {
		case 1: courses = OpenFile();
			break;
		case 2: printList(courses);
			break;
		case 3: searchList(courses);
			break;
		case 4: cout << "Exit\n";
			break;
		default: cout << "Invalid Input\n";
		}
	} 
	while (input != 4);
	return 0;
}
